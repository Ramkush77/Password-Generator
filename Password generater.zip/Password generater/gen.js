function generatePass() {
    const length = document.getElementById('length').value;
    const useLowercase = document.getElementById('lowercase').checked;
    const useUppercase = document.getElementById('uppercase').checked;
    const useNumbers = document.getElementById('numbers').checked;
    const useSymbols = document.getElementById('symbols').checked;

    const lowerChars = "abcdefghijklmnopqrstuvwxyz";
    const upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const numberChars = "0123456789";
    const symbolChars = "!@#$%&";

    let charPool = "";
    if (useLowercase) charPool += lowerChars;
    if (useUppercase) charPool += upperChars;
    if (useNumbers) charPool += numberChars;
    if (useSymbols) charPool += symbolChars;

    if (charPool === "") {
        alert("Please select at least one character type.");
        return;
    }

    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charPool.length);
        password += charPool[randomIndex];
    }

    document.getElementById('password').innerText = password;
}

function copyClip() {
    const passwordText = document.getElementById('password').innerText;
    if (!passwordText) return;
    
    navigator.clipboard.writeText(passwordText).then(() => {
        alert("Password copied to clipboard!");
    });
}
